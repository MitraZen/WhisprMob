﻿-- Extract all triggers
SELECT 
    t.trigger_name,
    t.event_manipulation,
    t.event_object_table,
    t.action_timing,
    t.action_orientation,
    t.action_statement,
    pg_get_triggerdef(t.oid) as trigger_definition
FROM information_schema.triggers t
JOIN pg_trigger pt ON t.trigger_name = pt.tgname
WHERE t.trigger_schema = 'public'
ORDER BY t.event_object_table, t.trigger_name;

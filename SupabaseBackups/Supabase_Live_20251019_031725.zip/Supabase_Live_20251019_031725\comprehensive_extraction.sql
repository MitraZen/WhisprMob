﻿-- Comprehensive Supabase Database Extraction Script
-- Generated on: 2025-10-19 03:17:26
-- This script extracts all database objects from your live Supabase database

-- =============================================
-- EXTRACTION QUERIES
-- =============================================

-- 1. Extract all custom functions
\copy (
SELECT 
    n.nspname as schema_name,
    p.proname as function_name,
    pg_get_function_result(p.oid) as return_type,
    pg_get_function_arguments(p.oid) as arguments,
    CASE 
        WHEN p.prokind = 'f' THEN 'function'
        WHEN p.prokind = 'p' THEN 'procedure'
        WHEN p.prokind = 'a' THEN 'aggregate'
        WHEN p.prokind = 'w' THEN 'window'
        ELSE 'other'
    END as function_type,
    pg_get_functiondef(p.oid) as function_definition,
    obj_description(p.oid, 'pg_proc') as description
FROM pg_proc p
JOIN pg_namespace n ON p.pronamespace = n.oid
WHERE n.nspname = 'public'
    AND p.prokind IN ('f', 'p')
ORDER BY p.proname
) TO 'functions_backup.csv' WITH CSV HEADER;

-- 2. Extract all triggers
\copy (
SELECT 
    t.trigger_name,
    t.event_manipulation,
    t.event_object_table,
    t.action_timing,
    t.action_orientation,
    t.action_statement,
    pg_get_triggerdef(t.oid) as trigger_definition
FROM information_schema.triggers t
JOIN pg_trigger pt ON t.trigger_name = pt.tgname
WHERE t.trigger_schema = 'public'
ORDER BY t.event_object_table, t.trigger_name
) TO 'triggers_backup.csv' WITH CSV HEADER;

-- 3. Extract table structures
\copy (
SELECT 
    t.table_name,
    c.column_name,
    c.data_type,
    c.character_maximum_length,
    c.is_nullable,
    c.column_default,
    CASE WHEN pk.column_name IS NOT NULL THEN 'YES' ELSE 'NO' END as is_primary_key
FROM information_schema.tables t
LEFT JOIN information_schema.columns c ON t.table_name = c.table_name
LEFT JOIN (
    SELECT ku.table_name, ku.column_name
    FROM information_schema.table_constraints tc
    JOIN information_schema.key_column_usage ku ON tc.constraint_name = ku.constraint_name
    WHERE tc.constraint_type = 'PRIMARY KEY'
) pk ON t.table_name = pk.table_name AND c.column_name = pk.column_name
WHERE t.table_schema = 'public'
    AND t.table_type = 'BASE TABLE'
ORDER BY t.table_name, c.ordinal_position
) TO 'tables_backup.csv' WITH CSV HEADER;

-- 4. Extract all indexes
\copy (
SELECT 
    schemaname,
    tablename,
    indexname,
    indexdef
FROM pg_indexes
WHERE schemaname = 'public'
ORDER BY tablename, indexname
) TO 'indexes_backup.csv' WITH CSV HEADER;

-- 5. Extract Row Level Security policies
\copy (
SELECT 
    schemaname,
    tablename,
    policyname,
    permissive,
    roles,
    cmd,
    qual,
    with_check
FROM pg_policies
WHERE schemaname = 'public'
ORDER BY tablename, policyname
) TO 'policies_backup.csv' WITH CSV HEADER;

-- 6. Extract all views
\copy (
SELECT 
    table_name,
    view_definition
FROM information_schema.views
WHERE table_schema = 'public'
ORDER BY table_name
) TO 'views_backup.csv' WITH CSV HEADER;

-- 7. Extract all sequences
\copy (
SELECT 
    sequence_name,
    data_type,
    start_value,
    minimum_value,
    maximum_value,
    increment,
    cycle_option
FROM information_schema.sequences
WHERE sequence_schema = 'public'
ORDER BY sequence_name
) TO 'sequences_backup.csv' WITH CSV HEADER;

-- =============================================
-- SUMMARY QUERIES
-- =============================================

-- Count all objects
SELECT 'Functions' as object_type, COUNT(*) as count FROM pg_proc p JOIN pg_namespace n ON p.pronamespace = n.oid WHERE n.nspname = 'public' AND p.prokind IN ('f', 'p')
UNION ALL
SELECT 'Triggers' as object_type, COUNT(*) as count FROM information_schema.triggers WHERE trigger_schema = 'public'
UNION ALL
SELECT 'Tables' as object_type, COUNT(*) as count FROM information_schema.tables WHERE table_schema = 'public' AND table_type = 'BASE TABLE'
UNION ALL
SELECT 'Indexes' as object_type, COUNT(*) as count FROM pg_indexes WHERE schemaname = 'public'
UNION ALL
SELECT 'Policies' as object_type, COUNT(*) as count FROM pg_policies WHERE schemaname = 'public'
UNION ALL
SELECT 'Views' as object_type, COUNT(*) as count FROM information_schema.views WHERE table_schema = 'public'
UNION ALL
SELECT 'Sequences' as object_type, COUNT(*) as count FROM information_schema.sequences WHERE sequence_schema = 'public';
